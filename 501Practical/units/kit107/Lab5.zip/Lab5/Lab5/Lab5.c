/*
	KIT107 Programming 
	Lab 5: Harness
	
	Author: Julian Dermoudy
*/

#include "queue.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	queue q;
	int i, n, s;
	int *sp;

	n = rand() % 10 + 1;

	init_queue(&q);

	printf("Adding %d students...", n);
	for (i = 1; i <= n; i++)
	{
		s = rand() % 1000000;
		sp = (int *)malloc(sizeof(int));
		*sp = s;
		printf("[%06d] ", s);
		add(q, sp);
	}
	printf("done.\n");
	printf("Queue is <%s>\n", toString(q, "%06d"));

	printf("Queue is empty? %s\n", isEmpty(q) ? "true" : "false");
	printf("Front is %06d\n", *((int *)(front(q))));
	printf("Removing front item...");
	rear(q);
	printf("done.\n");
	printf("Front is now %06d\n", *((int *)(front(q))));
	printf("Queue is <%s>\n", toString(q, "%06d"));
}
