// KIT107 Lab 5: Queue
/*
 * Specification for the Queue ADT
 * Author Julian Dermoudy
 * Version 27/3/14
*/

#include "mybool.h"

struct queue_int;
typedef struct queue_int *queue;

void init_queue(queue *q);
bool isEmpty(queue q);
void add(queue q,void *i);
void *front(queue q);
void rear(queue q);
