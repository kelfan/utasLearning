#ifndef MY_BOOL
#define MY_BOOL
typedef enum {false=0,true=1} bool;
#endif
