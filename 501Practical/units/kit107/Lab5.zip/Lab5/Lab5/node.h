// KIT107 Slide 51: Node
/*
 * Specification for the Node ADT
 * Author Julian Dermoudy
 * Version 23/3/14
*/

#include "mybool.h"

struct node_int;
typedef struct node_int *node;

void init_node(node *v, void *o);
void setData(node v, void *o);
void setNext(node v, node n);
void *getData(node v);
node getNext(node v);
